var mygallery=new simpleGallery({
wrapperid: "simplegallery5", //ID of main gallery container,
dimensions: [250, 200], //width/height of gallery in pixels. Should reflect dimensions of the images exactly
imagearray: [
["img/23_how_your_front_airbags_work/10001.png","","","" ],
["img/23_how_your_front_airbags_work/10002.png","","","" ],
["img/23_how_your_front_airbags_work/10003.png","","","" ],
["img/23_how_your_front_airbags_work/10004.png","","","" ],
["img/23_how_your_front_airbags_work/10005.png","","","" ],
["img/23_how_your_front_airbags_work/10006.png","","","" ],
["img/23_how_your_front_airbags_work/10007.png","","","" ],
["img/23_how_your_front_airbags_work/10008.png","","","" ],
["img/23_how_your_front_airbags_work/10009.png","","","" ],
["img/23_how_your_front_airbags_work/10010.png","","","" ],
["img/23_how_your_front_airbags_work/10011.png","","","" ],
["img/23_how_your_front_airbags_work/10012.png","","","" ],
["img/23_how_your_front_airbags_work/10013.png","","","" ],
["img/23_how_your_front_airbags_work/10014.png","","","" ],
["img/23_how_your_front_airbags_work/10015.png","","","" ],
["img/23_how_your_front_airbags_work/10016.png","","","" ],
["img/23_how_your_front_airbags_work/10017.png","","","" ],
["img/23_how_your_front_airbags_work/10018.png","","","" ],
["img/23_how_your_front_airbags_work/10019.png","","","" ],
["img/23_how_your_front_airbags_work/10020.png","","","" ],
["img/23_how_your_front_airbags_work/10021.png","","","" ],
["img/23_how_your_front_airbags_work/10022.png","","","" ],
["img/23_how_your_front_airbags_work/10023.png","","","" ]
],
autoplay: [true, 1, 1], //[auto_play_boolean, delay_btw_slide_millisec, cycles_before_stopping_int]
persist: false, //remember last viewed slide and recall within same session?
fadeduration: 5, //transition duration (milliseconds)
oninit:function(){ //event that fires when gallery has initialized/ ready to run
//Keyword "this": references current gallery instance (ie: try this.navigate("play/pause"))
},
onslide:function(curslide, i){ //event that fires after each slide is shown
//Keyword "this": references current gallery instance
//curslide: returns DOM reference to current slide's DIV (ie: try alert(curslide.innerHTML)
//i: integer reflecting current image within collection being shown (0=1st image, 1=2nd etc)
}
})
