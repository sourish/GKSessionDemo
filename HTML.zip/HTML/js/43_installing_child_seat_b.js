var mygallery=new simpleGallery({
wrapperid: "simplegallery8", //ID of main gallery container,
dimensions: [250, 200], //width/height of gallery in pixels. Should reflect dimensions of the images exactly
imagearray: [
["img/43_installing_child_seat_b/10001.png","","","" ],
["img/43_installing_child_seat_b/10002.png","","","" ],
["img/43_installing_child_seat_b/10003.png","","","" ],
["img/43_installing_child_seat_b/10004.png","","","" ],
["img/43_installing_child_seat_b/10005.png","","","" ],
["img/43_installing_child_seat_b/10006.png","","","" ],
["img/43_installing_child_seat_b/10007.png","","","" ],
["img/43_installing_child_seat_b/10008.png","","","" ],
["img/43_installing_child_seat_b/10009.png","","","" ],
["img/43_installing_child_seat_b/10010.png","","","" ],
["img/43_installing_child_seat_b/10011.png","","","" ],
["img/43_installing_child_seat_b/10012.png","","","" ],
["img/43_installing_child_seat_b/10013.png","","","" ],
["img/43_installing_child_seat_b/10014.png","","","" ],
["img/43_installing_child_seat_b/10015.png","","","" ],
["img/43_installing_child_seat_b/10016.png","","","" ],
["img/43_installing_child_seat_b/10017.png","","","" ],
["img/43_installing_child_seat_b/10018.png","","","" ],
["img/43_installing_child_seat_b/10019.png","","","" ],
["img/43_installing_child_seat_b/10020.png","","","" ],
["img/43_installing_child_seat_b/10021.png","","","" ],
["img/43_installing_child_seat_b/10022.png","","","" ],
["img/43_installing_child_seat_b/10023.png","","","" ],
["img/43_installing_child_seat_b/10024.png","","","" ],
["img/43_installing_child_seat_b/10025.png","","","" ]
],
autoplay: [true, 1, 1], //[auto_play_boolean, delay_btw_slide_millisec, cycles_before_stopping_int]
persist: false, //remember last viewed slide and recall within same session?
fadeduration: 5, //transition duration (milliseconds)
oninit:function(){ //event that fires when gallery has initialized/ ready to run
//Keyword "this": references current gallery instance (ie: try this.navigate("play/pause"))
},
onslide:function(curslide, i){ //event that fires after each slide is shown
//Keyword "this": references current gallery instance
//curslide: returns DOM reference to current slide's DIV (ie: try alert(curslide.innerHTML)
//i: integer reflecting current image within collection being shown (0=1st image, 1=2nd etc)
}
})

